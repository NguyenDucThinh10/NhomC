using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KoiProject.WebApplication.Pages
{
    public class Phongthuy2024Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
