using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KoiProject.WebApplication.Pages
{
    public class DangNhapModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
