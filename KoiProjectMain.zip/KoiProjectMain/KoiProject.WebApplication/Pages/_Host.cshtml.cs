using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KoiProject.WebApplication.Pages
{
    public class _HostModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
